// screens.jsx — Login, Role select, Stockpile, Jetty, Admin + PhoneApp shell
const { useState: useS, useEffect: useE, useMemo } = React;

// ─────────────────────────────────────────── LOGIN
function LoginScreen({ onLogin }) {
  const [u, setU] = useS('operator.stockpile');
  const [p, setP] = useS('demo1234');
  return (
    <div className="screen-wrap">
      <StatusBar />
      <div className="login-wrap">
        <div className="stack" style={{ gap: 14, alignItems: 'flex-start' }}>
          <img className="login-logo" src="assets/mergecoal-logo.png" alt="MergeCoal" />
          <div className="brand-sub" style={{ marginTop: 0 }}>Clock-in &amp; clock-out hauling batubara · Tambang → Jetty</div>
        </div>
        <div className="stack" style={{ gap: 14 }}>
          <Field label="Nama Pengguna">
            <input className="input" value={u} onChange={(e) => setU(e.target.value)} autoComplete="off" />
          </Field>
          <Field label="Kata Sandi">
            <input className="input" type="password" value={p} onChange={(e) => setP(e.target.value)} />
          </Field>
          <button className="btn btn-brand" style={{ marginTop: 4 }} onClick={onLogin}>Masuk</button>
        </div>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <SyncChip online={false} />
          <span className="muted" style={{ fontSize: 12.5 }}>Mode offline siap</span>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────── ROLE SELECT
const ROLES = [
  { key: 'stockpile', name: 'Operator Stockpile', desc: 'Jam Masuk & Jam Keluar truk di tambang', icon: I.truck },
  { key: 'jetty', name: 'Operator Jetty', desc: 'Timbang ulang & verifikasi di jetty', icon: I.anchor },
  { key: 'admin', name: 'Admin', desc: 'Ringkasan harian & ekspor data', icon: I.shield },
];
function RoleSelect({ onPick, onBack }) {
  return (
    <div className="screen-wrap">
      <StatusBar />
      <AppHeader kicker="Masuk sebagai" title="Pilih Peran" onBack={onBack} />
      <div className="screen">
        {ROLES.map((r) => (
          <button key={r.key} className="role-card" onClick={() => onPick(r.key)}>
            <span className="role-ico"><r.icon width="26" height="26" /></span>
            <div className="grow">
              <div className="role-name">{r.name}</div>
              <div className="role-desc">{r.desc}</div>
            </div>
            <I.chevR width="18" height="18" style={{ color: 'var(--text-3)' }} />
          </button>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────── CP1 — Jam Masuk
const CP1_INIT = { no_lambung: '', jetty_destination: '', coal_quality: '', cuaca: '', tare_site_kg: '' };
function JamMasuk({ store }) {
  const [f, setF] = useS(CP1_INIT);
  const [ok, setOk] = useS(null);
  const [err, setErr] = useS('');
  const set = (k, v) => { setF((s) => ({ ...s, [k]: v })); setErr(''); };
  const valid = f.no_lambung.trim() && f.jetty_destination && f.coal_quality && f.cuaca.trim() && parseInt(f.tare_site_kg, 10) > 0;

  function submit() {
    if (!valid) { setErr('Lengkapi semua kolom sebelum menyimpan.'); return; }
    const trip = store.createTrip({ ...f, no_lambung: f.no_lambung.trim().toUpperCase(), tare_site_kg: parseInt(f.tare_site_kg, 10) });
    setOk(trip); setF(CP1_INIT);
  }

  if (ok) return (
    <div className="stack" style={{ gap: 14 }}>
      <div className="banner">
        <span className="b-ico"><I.check width="20" height="20" /></span>
        <div className="grow">
          <div className="b-title">Jam Masuk tercatat</div>
          <div className="b-text">Tiket #{ok.no_tiket} · {ok.no_lambung} · Tara {kg(ok.tare_site_kg)} kg</div>
        </div>
      </div>
      <button className="btn btn-ghost" onClick={() => setOk(null)}>Catat truk berikutnya</button>
    </div>
  );

  return (
    <div className="stack" style={{ gap: 16 }}>
      <Field label="No. Lambung Truk">
        <input className="input num" placeholder="KB 0000" value={f.no_lambung}
          onChange={(e) => set('no_lambung', e.target.value.toUpperCase())} style={{ textTransform: 'uppercase' }} />
      </Field>
      <Field label="Tujuan Jetty">
        <Segmented value={f.jetty_destination} onChange={(v) => set('jetty_destination', v)}
          options={[{ value: 'hasnur', label: 'Hasnur' }, { value: 'talenta', label: 'Talenta' }]} />
      </Field>
      <Field label="Kualitas Batubara">
        <Segmented value={f.coal_quality} onChange={(v) => set('coal_quality', v)}
          options={[{ value: 'raw', label: 'Raw', sub: 'Mentah' }, { value: 'clean', label: 'Clean', sub: 'Bersih' }]} />
      </Field>
      <Field label="Cuaca">
        <Segmented value={f.cuaca} onChange={(v) => set('cuaca', v)}
          options={[{ value: 'Cerah', label: 'Cerah' }, { value: 'Berawan', label: 'Berawan' }, { value: 'Hujan', label: 'Hujan' }]} />
      </Field>
      <Field label="Berat Kosong" hint="Tara · kg">
        <input className="input num" inputMode="numeric" placeholder="0" value={f.tare_site_kg}
          onChange={(e) => set('tare_site_kg', e.target.value.replace(/\D/g, ''))} />
      </Field>
      {err && <div className="alert">{err}</div>}
      <button className="btn btn-accent" onClick={submit} disabled={!valid}>
        <I.arrowIn width="22" height="22" /> Catat Jam Masuk
      </button>
    </div>
  );
}

// ─────────────────────────────────────────── CP2 — Jam Keluar
function JamKeluar({ store }) {
  const [sel, setSel] = useS(null);
  const [gross, setGross] = useS('');
  const [ok, setOk] = useS(null);
  const pending = store.trips.filter((t) => t.status === 'pending');
  const g = parseInt(gross, 10) || 0;
  const netto = sel && g ? g - sel.tare_site_kg : null;

  function submit() {
    const u = store.submitCP2(sel.trip_id, g);
    setOk(u); setSel(null); setGross('');
  }

  if (ok) return (
    <div className="stack" style={{ gap: 14 }}>
      <div className="banner">
        <span className="b-ico"><I.check width="20" height="20" /></span>
        <div className="grow">
          <div className="b-title">Jam Keluar tercatat — truk berangkat</div>
          <div className="b-text">{ok.no_lambung} · Netto <b style={{ color: 'var(--st-done-fg)' }}>{kg(ok.netto_site_kg)} kg</b></div>
        </div>
      </div>
      <button className="btn btn-ghost" onClick={() => setOk(null)}>Selesai</button>
    </div>
  );

  if (sel) return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="between">
        <div className="section-label">Detail Trip</div>
        <StatusPill status="pending" />
      </div>
      <div className="card">
        <div className="between" style={{ marginBottom: 14 }}>
          <div>
            <div className="muted" style={{ fontSize: 12 }}>#{sel.no_tiket} · {QUALITY[sel.coal_quality]} · {JETTY[sel.jetty_destination]}</div>
            <div style={{ fontFamily: 'var(--font-num)', fontWeight: 700, fontSize: 22 }}>{sel.no_lambung}</div>
          </div>
          <DestChip dest={sel.jetty_destination} />
        </div>
        <div className="info-grid">
          <div className="info-cell"><div className="k">Tara Site</div><div className="v">{kg(sel.tare_site_kg)}</div></div>
          <div className="info-cell"><div className="k">Jam Masuk</div><div className="v">{toWITA(sel.cp1_timestamp)}</div></div>
        </div>
      </div>
      <Field label="Berat Isi" hint="Bruto · kg">
        <input className="input num" inputMode="numeric" placeholder="0" value={gross} autoFocus
          onChange={(e) => setGross(e.target.value.replace(/\D/g, ''))} />
      </Field>
      {netto != null && (
        <div className="card" style={{ padding: '14px 16px' }}>
          <div className="between">
            <span className="muted" style={{ fontSize: 13, fontWeight: 600 }}>Netto Muatan</span>
            <Weight value={netto} accent={netto > 0} />
          </div>
        </div>
      )}
      <div className="row" style={{ gap: 10 }}>
        <button className="btn btn-ghost grow" onClick={() => { setSel(null); setGross(''); }}>Batal</button>
        <button className="btn btn-accent grow" onClick={submit} disabled={!(netto > 0)}>
          <I.arrowOut width="20" height="20" /> Jam Keluar
        </button>
      </div>
    </div>
  );

  return (
    <div className="stack" style={{ gap: 14 }}>
      <div className="section-label">Pilih truk yang akan keluar</div>
      <TripListCard title="Menunggu Keluar" sub={`${pending.length} truk di stockpile`}
        trips={pending} getTap={(t) => () => { setSel(t); setGross(''); }} cta="Catat keluar" />
    </div>
  );
}

// ─────────────────────────────────────────── CP3 — Jetty timbang
function JettyTimbang({ store }) {
  const [sel, setSel] = useS(null);
  const [gross, setGross] = useS('');
  const [ok, setOk] = useS(null);
  const transit = store.trips.filter((t) => t.status === 'in_transit');
  const g = parseInt(gross, 10) || 0;
  const preview = sel && g ? { netto: g, dev: g - (sel.netto_site_kg || 0) } : null;

  function submit() {
    const u = store.submitCP3(sel.trip_id, g);
    setOk(u); setSel(null); setGross('');
  }

  if (ok) return (
    <div className="stack" style={{ gap: 14 }}>
      <div className="banner">
        <span className="b-ico"><I.check width="20" height="20" /></span>
        <div className="grow">
          <div className="b-title">Timbang jetty selesai — trip tuntas</div>
          <div className="b-text">{ok.no_lambung} · Netto jetty <b>{kg(ok.netto_jetty_kg)} kg</b> · Deviasi {kg(ok.deviasi_kg)} kg</div>
        </div>
      </div>
      <button className="btn btn-ghost" onClick={() => setOk(null)}>Selesai</button>
    </div>
  );

  if (sel) return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="between">
        <div className="section-label">Timbang Ulang — {JETTY[sel.jetty_destination]}</div>
        <StatusPill status="in_transit" />
      </div>
      <div className="card">
        <div className="between" style={{ marginBottom: 14 }}>
          <div>
            <div className="muted" style={{ fontSize: 12 }}>#{sel.no_tiket} · {QUALITY[sel.coal_quality]}</div>
            <div style={{ fontFamily: 'var(--font-num)', fontWeight: 700, fontSize: 22 }}>{sel.no_lambung}</div>
          </div>
          <DestChip dest={sel.jetty_destination} />
        </div>
        <div className="info-grid">
          <div className="info-cell"><div className="k">Netto Site</div><div className="v">{kg(sel.netto_site_kg)}</div></div>
          <div className="info-cell"><div className="k">Gross Site</div><div className="v">{kg(sel.gross_site_kg)}</div></div>
          <div className="info-cell"><div className="k">Jam Masuk</div><div className="v">{toWITA(sel.cp1_timestamp)}</div></div>
          <div className="info-cell"><div className="k">Jam Keluar</div><div className="v">{toWITA(sel.cp2_timestamp)}</div></div>
        </div>
      </div>
      <Field label={`Berat Isi di ${JETTY[sel.jetty_destination]}`} hint="Bruto · kg">
        <input className="input num" inputMode="numeric" placeholder="0" value={gross} autoFocus
          onChange={(e) => setGross(e.target.value.replace(/\D/g, ''))} />
      </Field>
      {preview && (
        <div className="card" style={{ padding: 14 }}>
          <div className="between" style={{ marginBottom: 8 }}>
            <span className="muted" style={{ fontSize: 13, fontWeight: 600 }}>Netto Jetty</span>
            <Weight value={preview.netto} accent />
          </div>
          <div className="between" style={{ paddingTop: 8, borderTop: '1px solid var(--border)' }}>
            <span className="muted" style={{ fontSize: 13, fontWeight: 600 }}>Deviasi vs site</span>
            <span style={{ fontFamily: 'var(--font-num)', fontWeight: 700, fontSize: 18, color: preview.dev < 0 ? 'var(--danger)' : 'var(--st-transit-fg)' }}>
              {preview.dev > 0 ? '+' : ''}{kg(preview.dev)} kg
            </span>
          </div>
        </div>
      )}
      <div className="row" style={{ gap: 10 }}>
        <button className="btn btn-ghost grow" onClick={() => { setSel(null); setGross(''); }}>Batal</button>
        <button className="btn btn-accent grow" onClick={submit} disabled={!(g > 0)}>
          <I.scale width="20" height="20" /> Selesai
        </button>
      </div>
    </div>
  );

  return (
    <div className="stack" style={{ gap: 14 }}>
      <div className="section-label">Truk dalam perjalanan ke jetty</div>
      <TripListCard title="Antrian Timbang" sub={`${transit.length} truk menuju jetty`}
        trips={transit} getTap={(t) => () => { setSel(t); setGross(''); }} cta="Timbang" />
    </div>
  );
}

// ─────────────────────────────────────────── Export
function ExportPanel() {
  const [range, setRange] = useS('today');
  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="section-label">Ekspor Data Trip</div>
      <Field label="Rentang Tanggal">
        <Segmented value={range} onChange={setRange}
          options={[{ value: 'today', label: 'Hari Ini' }, { value: 'week', label: 'Minggu' }, { value: 'month', label: 'Bulan' }]} />
      </Field>
      <div className="card">
        <div className="info-grid">
          <div className="info-cell"><div className="k">Total Trip</div><div className="v">128</div></div>
          <div className="info-cell"><div className="k">Total Netto</div><div className="v">3.94 jt</div></div>
          <div className="info-cell"><div className="k">Hasnur</div><div className="v">74</div></div>
          <div className="info-cell"><div className="k">Talenta</div><div className="v">54</div></div>
        </div>
      </div>
      <button className="btn btn-brand"><I.download width="20" height="20" /> Unduh Excel</button>
      <p className="muted" style={{ fontSize: 12.5, textAlign: 'center' }}>File .xlsx berisi semua kolom timbang & deviasi</p>
    </div>
  );
}

// ─────────────────────────────────────────── Admin ringkasan
function AdminSummary({ store }) {
  const t = store.trips;
  const done = t.filter((x) => x.status === 'completed');
  const transit = t.filter((x) => x.status === 'in_transit').length;
  const pending = t.filter((x) => x.status === 'pending').length;
  const netto = t.reduce((s, x) => s + (x.netto_site_kg || 0), 0);
  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="card">
        <div className="muted" style={{ fontSize: 12.5, fontWeight: 600 }}>Total muatan hari ini</div>
        <div style={{ marginTop: 6 }}><Weight value={netto} unit="kg" size="lg" accent /></div>
        <div className="row" style={{ gap: 8, marginTop: 14 }}>
          <span className="status-pill st-pending"><span className="dot" />{pending} stockpile</span>
          <span className="status-pill st-transit"><span className="dot" />{transit} jalan</span>
          <span className="status-pill st-done"><span className="dot" />{done.length} selesai</span>
        </div>
      </div>
      <div className="section-label">Trip Terbaru</div>
      <TripListCard title="Trip Hari Ini" sub={`${t.length} truk · diperbarui tiap 30 dtk`} trips={t} />
    </div>
  );
}

// ─────────────────────────────────────────── tab bars
const TABS = {
  stockpile: [
    { key: 'cp1', label: 'Masuk', icon: I.arrowIn },
    { key: 'cp2', label: 'Keluar', icon: I.arrowOut, badge: (s) => s.trips.filter((t) => t.status === 'pending').length },
    { key: 'trips', label: 'Trip', icon: I.list },
    { key: 'export', label: 'Ekspor', icon: I.download },
  ],
  jetty: [
    { key: 'cp3', label: 'Timbang', icon: I.scale, badge: (s) => s.trips.filter((t) => t.status === 'in_transit').length },
    { key: 'trips', label: 'Trip', icon: I.list },
    { key: 'export', label: 'Ekspor', icon: I.download },
  ],
  admin: [
    { key: 'summary', label: 'Ringkasan', icon: I.shield },
    { key: 'trips', label: 'Trip', icon: I.list },
    { key: 'export', label: 'Ekspor', icon: I.download },
  ],
};
function BottomTabs({ tabs, active, onChange, store }) {
  return (
    <div className="tabbar">
      {tabs.map((t) => {
        const badge = t.badge ? t.badge(store) : 0;
        return (
          <button key={t.key} className={`tab ${active === t.key ? 'active' : ''}`} onClick={() => onChange(t.key)}>
            {badge > 0 && <span className="tab-badge">{badge}</span>}
            <t.icon width="24" height="24" />
            <span>{t.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────── Role app (with tabs)
const ROLE_META = {
  stockpile: { kicker: 'Operator Stockpile', titles: { cp1: 'Jam Masuk', cp2: 'Jam Keluar', trips: 'Trip Hari Ini', export: 'Ekspor' }, first: 'cp1' },
  jetty: { kicker: 'Operator Jetty', titles: { cp3: 'Timbang Jetty', trips: 'Trip Hari Ini', export: 'Ekspor' }, first: 'cp3' },
  admin: { kicker: 'Admin', titles: { summary: 'Ringkasan', trips: 'Trip Hari Ini', export: 'Ekspor' }, first: 'summary' },
};
function RoleApp({ role, tab, setTab, store, onSignOut }) {
  const meta = ROLE_META[role];
  const allTrips = store.trips;
  let body;
  if (tab === 'cp1') body = <JamMasuk store={store} />;
  else if (tab === 'cp2') body = <JamKeluar store={store} />;
  else if (tab === 'cp3') body = <JettyTimbang store={store} />;
  else if (tab === 'summary') body = <AdminSummary store={store} />;
  else if (tab === 'export') body = <ExportPanel />;
  else body = <TripListCard title="Trip Hari Ini" sub={`${allTrips.length} truk · diperbarui tiap 30 dtk`} trips={allTrips} onRefresh={() => {}} />;

  // intro list under the entry forms
  const showList = tab === 'cp1';

  return (
    <div className="screen-wrap">
      <StatusBar />
      <AppHeader kicker={meta.kicker} title={meta.titles[tab]} logo
        right={
          <div className="row" style={{ gap: 8 }}>
            <SyncChip online compact />
            <button className="ah-icon-btn" onClick={onSignOut} aria-label="Keluar"><I.logout width="18" height="18" /></button>
          </div>
        } />
      <div className="screen">
        {body}
        {showList && (
          <TripListCard title="Trip Hari Ini" sub={`${allTrips.length} truk · diperbarui tiap 30 dtk`}
            trips={allTrips} onRefresh={() => {}} />
        )}
      </div>
      <BottomTabs tabs={TABS[role]} active={tab} onChange={setTab} store={store} />
    </div>
  );
}

// ─────────────────────────────────────────── PhoneApp (per-device state machine)
function PhoneApp({ direction, theme, density, store, broadcast, initial }) {
  const init = initial || {};
  const [screen, setScreen] = useS(init.screen || 'app');      // login | role | app
  const [role, setRole] = useS(init.role || 'stockpile');
  const [tab, setTab] = useS(init.tab || 'cp1');

  // respond to toolbar broadcasts from Root
  useE(() => {
    if (!broadcast) return;
    const { screen: s, role: r, tab: tb } = broadcast;
    if (s) setScreen(s);
    if (r) { setRole(r); setTab(tb || ROLE_META[r].first); }
    else if (tb) setTab(tb);
  }, [broadcast && broadcast.nonce]);

  let inner;
  if (screen === 'login') inner = <LoginScreen onLogin={() => setScreen('role')} />;
  else if (screen === 'role') inner = <RoleSelect onPick={(r) => { setRole(r); setTab(ROLE_META[r].first); setScreen('app'); }} onBack={() => setScreen('login')} />;
  else inner = <RoleApp role={role} tab={tab} setTab={setTab} store={store} onSignOut={() => setScreen('login')} />;

  return (
    <div className="device" data-direction={direction} data-theme={theme} data-density={density}>
      <div className="island" />
      {inner}
      <div className="home-ind" />
    </div>
  );
}

Object.assign(window, { PhoneApp });
