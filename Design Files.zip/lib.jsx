// lib.jsx — formatters, labels, icons, seed data, shared store
// Indonesian-first copy for the Hauling Tracker redesign.

const WITA_OPTS = { timeZone: 'Asia/Makassar', hour: '2-digit', minute: '2-digit', hour12: false };
function toWITA(ts) {
  if (!ts) return '—';
  return new Intl.DateTimeFormat('id-ID', WITA_OPTS).format(new Date(ts));
}
function nowWITA() {
  return new Intl.DateTimeFormat('id-ID', WITA_OPTS).format(new Date());
}
function elapsed(ts) {
  if (!ts) return '';
  const mins = Math.floor((Date.now() - new Date(ts).getTime()) / 60000);
  if (mins < 1) return 'baru saja';
  if (mins < 60) return `${mins} mnt lalu`;
  return `${Math.floor(mins / 60)} j ${mins % 60} m lalu`;
}
function kg(n) { return n == null ? '—' : Number(n).toLocaleString('id-ID'); }

const STATUS = {
  pending:    { cls: 'st-pending', label: 'Di Stockpile' },
  in_transit: { cls: 'st-transit', label: 'Perjalanan' },
  completed:  { cls: 'st-done',    label: 'Selesai' },
};
const JETTY = { hasnur: 'Hasnur', talenta: 'Talenta' };
const QUALITY = { raw: 'Raw', clean: 'Clean' };
const QUALITY_ID = { raw: 'Mentah', clean: 'Bersih' };

// ── seed trips (relative to "now") ──
const M = 60000;
function seedTrips() {
  const now = Date.now();
  return [
    { trip_id: 't1', no_tiket: 1041, no_lambung: 'KB 8821', jetty_destination: 'hasnur', coal_quality: 'raw',
      cuaca: 'Cerah', tare_site_kg: 18420, gross_site_kg: 49100, netto_site_kg: 30680,
      gross_jetty_kg: 49020, netto_jetty_kg: 30600, deviasi_kg: -80, status: 'completed',
      cp1_timestamp: now - 196*M, cp2_timestamp: now - 168*M, cp3_timestamp: now - 96*M },
    { trip_id: 't2', no_tiket: 1042, no_lambung: 'KB 7390', jetty_destination: 'talenta', coal_quality: 'clean',
      cuaca: 'Berawan', tare_site_kg: 17980, gross_site_kg: 47650, netto_site_kg: 29670,
      gross_jetty_kg: null, netto_jetty_kg: null, deviasi_kg: null, status: 'in_transit',
      cp1_timestamp: now - 142*M, cp2_timestamp: now - 119*M, cp3_timestamp: null },
    { trip_id: 't3', no_tiket: 1043, no_lambung: 'KB 9105', jetty_destination: 'hasnur', coal_quality: 'raw',
      cuaca: 'Cerah', tare_site_kg: 18650, gross_site_kg: 50240, netto_site_kg: 31590,
      gross_jetty_kg: null, netto_jetty_kg: null, deviasi_kg: null, status: 'in_transit',
      cp1_timestamp: now - 88*M, cp2_timestamp: now - 64*M, cp3_timestamp: null },
    { trip_id: 't4', no_tiket: 1044, no_lambung: 'KB 8821', jetty_destination: 'talenta', coal_quality: 'raw',
      cuaca: 'Hujan ringan', tare_site_kg: 18410, gross_site_kg: null, netto_site_kg: null,
      gross_jetty_kg: null, netto_jetty_kg: null, deviasi_kg: null, status: 'pending',
      cp1_timestamp: now - 34*M, cp2_timestamp: null, cp3_timestamp: null },
    { trip_id: 't5', no_tiket: 1045, no_lambung: 'KB 6644', jetty_destination: 'hasnur', coal_quality: 'clean',
      cuaca: 'Cerah', tare_site_kg: 17760, gross_site_kg: null, netto_site_kg: null,
      gross_jetty_kg: null, netto_jetty_kg: null, deviasi_kg: null, status: 'pending',
      cp1_timestamp: now - 12*M, cp2_timestamp: null, cp3_timestamp: null },
  ];
}

// ── icons (stroke, currentColor) ──
const I = {
  truck: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M14 17V6a1 1 0 00-1-1H3a1 1 0 00-1 1v11h2"/><path d="M14 9h4l3 3.5V17h-3"/><circle cx="7" cy="17.5" r="2"/><circle cx="17" cy="17.5" r="2"/></svg>),
  arrowIn: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M5 21h14"/></svg>),
  arrowOut: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 21V9"/><path d="M7 14l5-5 5 5"/><path d="M5 3h14"/></svg>),
  scale: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 3v18"/><path d="M6 7h12"/><path d="M6 7l-3 7a3 3 0 006 0L6 7z"/><path d="M18 7l-3 7a3 3 0 006 0l-3-7z"/><path d="M7 21h10"/></svg>),
  anchor: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="5" r="2.5"/><path d="M12 8v13"/><path d="M5 12a7 7 0 0014 0"/><path d="M5 12H3m18 0h-2"/></svg>),
  list: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/></svg>),
  download: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M5 21h14"/></svg>),
  search: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>),
  check: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M5 13l4 4L19 7"/></svg>),
  refresh: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 12a9 9 0 11-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>),
  chevR: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M9 5l7 7-7 7"/></svg>),
  back: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M15 5l-7 7 7 7"/></svg>),
  logout: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>),
  weather: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="9" r="3.2"/><path d="M12 2v1.5M12 14.5V16M5.6 9H4M20 9h-1.6M7.4 4.4L6.3 3.3M17.7 3.3l-1.1 1.1"/><path d="M5 20h12a3 3 0 000-6 4.5 4.5 0 00-8.6-1.3"/></svg>),
  shield: (p={}) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/></svg>),
};

Object.assign(window, {
  toWITA, nowWITA, elapsed, kg, STATUS, JETTY, QUALITY, QUALITY_ID, seedTrips, I,
});
