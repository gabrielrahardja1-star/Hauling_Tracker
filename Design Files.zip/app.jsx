// app.jsx — Root: shared store, toolbar, 3 phones, tweaks
const { useState: uS, useEffect: uE, useMemo: uM, useCallback } = React;

const PHONES = [
  { id: 'login', tag: 'Masuk', desc: 'Sign-in berlogo MergeCoal', initial: { screen: 'login' } },
  { id: 'stockpile', tag: 'Operator Stockpile', desc: 'Jam Masuk · Jam Keluar', initial: { screen: 'app', role: 'stockpile', tab: 'cp1' } },
  { id: 'jetty', tag: 'Operator Jetty', desc: 'Timbang ulang di jetty', initial: { screen: 'app', role: 'jetty', tab: 'cp3' } },
];

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "density": "regular"
}/*EDITMODE-END*/;

function useStore() {
  const [trips, setTrips] = uS(seedTrips);
  const [ticket, setTicket] = uS(1046);

  const createTrip = useCallback((f) => {
    const now = Date.now();
    const trip = {
      trip_id: 'n' + now, no_tiket: ticket, no_lambung: f.no_lambung,
      jetty_destination: f.jetty_destination, coal_quality: f.coal_quality, cuaca: f.cuaca,
      tare_site_kg: f.tare_site_kg, gross_site_kg: null, netto_site_kg: null,
      gross_jetty_kg: null, netto_jetty_kg: null, deviasi_kg: null, status: 'pending',
      cp1_timestamp: now, cp2_timestamp: null, cp3_timestamp: null,
    };
    setTicket((n) => n + 1);
    setTrips((ts) => [trip, ...ts]);
    return trip;
  }, [ticket]);

  const submitCP2 = useCallback((id, gross) => {
    let res;
    setTrips((ts) => ts.map((t) => {
      if (t.trip_id !== id) return t;
      res = { ...t, gross_site_kg: gross, netto_site_kg: gross - t.tare_site_kg, status: 'in_transit', cp2_timestamp: Date.now() };
      return res;
    }));
    return res;
  }, []);

  const submitCP3 = useCallback((id, gross) => {
    let res;
    setTrips((ts) => ts.map((t) => {
      if (t.trip_id !== id) return t;
      res = { ...t, gross_jetty_kg: gross, netto_jetty_kg: gross, deviasi_kg: gross - (t.netto_site_kg || 0), status: 'completed', cp3_timestamp: Date.now() };
      return res;
    }));
    return res;
  }, []);

  return uM(() => ({ trips, createTrip, submitCP2, submitCP3 }), [trips, createTrip, submitCP2, submitCP3]);
}

function Root() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const store = useStore();
  const [broadcast, setBroadcast] = uS(null);
  const [sysDark, setSysDark] = uS(() => window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);

  uE(() => {
    if (!window.matchMedia) return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const fn = (e) => setSysDark(e.matches);
    mq.addEventListener && mq.addEventListener('change', fn);
    return () => mq.removeEventListener && mq.removeEventListener('change', fn);
  }, []);

  const theme = t.theme === 'auto' ? (sysDark ? 'dark' : 'light') : t.theme;
  const density = t.density;

  const cast = (payload) => setBroadcast({ ...payload, nonce: Date.now() });

  const NAVS = [
    { label: 'Login', p: { screen: 'login' } },
    { label: 'Stockpile', p: { screen: 'app', role: 'stockpile', tab: 'cp1' } },
    { label: 'Jetty', p: { screen: 'app', role: 'jetty', tab: 'cp3' } },
    { label: 'Admin', p: { screen: 'app', role: 'admin', tab: 'summary' } },
  ];

  return (
    <div className="stage">
      <div className="stage-head">
        <div className="row" style={{ gap: 16, alignItems: 'center' }}>
          <img src="assets/mergecoal-mark.png" alt="MergeCoal" style={{ height: 44, width: 'auto' }} />
          <div>
            <div className="stage-title">MergeCoal — Hauling Tracker · Earthworks</div>
            <div className="stage-sub">Arah terpilih, diwarnai ulang dengan biru logo MergeCoal. Tiga telepon berbagi satu basis data trip — catat truk di satu layar dan lihat statusnya bergerak. Atur tema &amp; kerapatan lewat panel Tweaks.</div>
          </div>
        </div>
        <div className="stage-toolbar">
          <div className="tool-group">
            <span className="tool-label">Layar</span>
            {NAVS.map((n) => (
              <button key={n.label} className="tool-btn" onClick={() => cast(n.p)}>{n.label}</button>
            ))}
          </div>
          <div className="tool-group">
            {['light', 'dark', 'auto'].map((m) => (
              <button key={m} className={`tool-btn ${t.theme === m ? 'active' : ''}`} onClick={() => setTweak('theme', m)}>
                {m === 'light' ? 'Terang' : m === 'dark' ? 'Gelap' : 'Auto'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="phones-rail">
        {PHONES.map((ph) => (
          <div className="phone-col" key={ph.id}>
            <div className="phone-tag">
              <span className="pt-letter" style={{ background: '#3c83c2' }}>
                <img src="assets/mergecoal-mark-white.png" alt="" style={{ width: 18, height: 'auto' }} />
              </span>
              <div>
                <div className="pt-name">{ph.tag}</div>
                <div className="pt-desc">{ph.desc}</div>
              </div>
            </div>
            <PhoneApp direction="b" theme={theme} density={density} store={store} broadcast={broadcast} initial={ph.initial} />
          </div>
        ))}
      </div>

      <TweaksPanel>
        <TweakSection label="Tampilan" />
        <TweakRadio label="Tema" value={t.theme} options={['light', 'dark', 'auto']}
          onChange={(v) => setTweak('theme', v)} />
        <TweakRadio label="Kerapatan" value={t.density} options={['compact', 'regular', 'comfy']}
          onChange={(v) => setTweak('density', v)} />
        <TweakSection label="Bandingkan layar" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {NAVS.map((n) => (
            <TweakButton key={n.label} label={n.label} onClick={() => cast(n.p)} />
          ))}
        </div>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root />);
