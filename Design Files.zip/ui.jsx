// ui.jsx — device frame, status bar, and shared UI atoms.
const { useState, useEffect } = React;

// ── live status bar ──
function StatusBar() {
  const [t, setT] = useState(nowWITA());
  useEffect(() => { const id = setInterval(() => setT(nowWITA()), 10000); return () => clearInterval(id); }, []);
  return (
    <div className="statusbar">
      <span className="sb-time">{t}</span>
      <div className="sb-right">
        <svg width="18" height="12" viewBox="0 0 18 12"><g fill="currentColor"><rect x="0" y="8" width="3" height="4" rx="1"/><rect x="5" y="5.5" width="3" height="6.5" rx="1"/><rect x="10" y="3" width="3" height="9" rx="1"/><rect x="15" y="0.5" width="3" height="11.5" rx="1"/></g></svg>
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M1 4.2A11 11 0 0115 4.2M3.4 6.8a7.2 7.2 0 019.2 0M5.8 9.3a3.6 3.6 0 014.4 0"/><circle cx="8" cy="11" r=".6" fill="currentColor" stroke="none"/></svg>
        <svg width="26" height="13" viewBox="0 0 26 13"><rect x="0.5" y="0.5" width="21" height="12" rx="3" fill="none" stroke="currentColor" strokeOpacity=".4"/><rect x="2" y="2" width="16" height="9" rx="1.6" fill="currentColor"/><rect x="23" y="4" width="2.2" height="5" rx="1" fill="currentColor" fillOpacity=".5"/></svg>
      </div>
    </div>
  );
}

// ── device shell ──
function Device({ direction, theme, density, children }) {
  return (
    <div className="device" data-direction={direction} data-theme={theme} data-density={density}>
      <div className="island" />
      <div className="screen-wrap">
        {children}
      </div>
      <div className="home-ind" />
    </div>
  );
}

// ── app header (inside screen, below status bar) ──
function AppHeader({ kicker, title, onBack, right, logo }) {
  return (
    <div className="appheader">
      <div className="row grow" style={{ gap: 12, minWidth: 0 }}>
        {onBack && (
          <button className="ah-icon-btn" onClick={onBack} aria-label="Kembali">
            <I.back width="20" height="20" />
          </button>
        )}
        {logo && !onBack && <img className="ah-logo" src="assets/mergecoal-mark.png" alt="MergeCoal" />}
        <div style={{ minWidth: 0, flex: 1 }}>
          {kicker && <div className="ah-kicker">{kicker}</div>}
          <div className="ah-title">{title}</div>
        </div>
      </div>
      {right}
    </div>
  );
}

function SyncChip({ online, compact }) {
  if (compact) {
    return (
      <span title={online ? 'Tersinkron' : 'Offline · 2 menunggu'}
        style={{ width: 34, height: 34, borderRadius: '50%', display: 'grid', placeItems: 'center', flexShrink: 0,
          background: `color-mix(in srgb, var(${online ? '--online' : '--offline'}) 18%, transparent)`,
          color: `var(${online ? '--online' : '--offline'})` }}>
        {online ? <I.check width="17" height="17" /> : <span style={{ width: 9, height: 9, borderRadius: '50%', background: 'currentColor' }} />}
      </span>
    );
  }
  return online
    ? <span className="sync-chip sync-online"><span className="dot" />Tersinkron</span>
    : <span className="sync-chip sync-offline"><span className="dot" />Offline · 2</span>;
}

function StatusPill({ status }) {
  const s = STATUS[status] || { cls: 'st-pending', label: status };
  return <span className={`status-pill ${s.cls}`}><span className="dot" />{s.label}</span>;
}

function DestChip({ dest }) {
  return <span className={`chip dest-${dest}`}><span className="dot" />{JETTY[dest]}</span>;
}

function Weight({ value, unit = 'kg', size, accent }) {
  return (
    <div className={`weight ${size === 'lg' ? 'lg' : ''} ${accent ? 'accent' : ''}`}>
      <span className="num">{kg(value)}</span>
      <span className="unit">{unit}</span>
    </div>
  );
}

// ── trip row ──
function TripRow({ t, onTap, cta }) {
  const tappable = !!onTap;
  return (
    <div className={`trip-row ${tappable ? 'tappable' : ''}`} onClick={onTap} role={tappable ? 'button' : undefined}>
      <div className="tr-top">
        <div className="tr-id">
          <span className="tr-ticket">#{t.no_tiket}</span>
          <span className="tr-lambung">{t.no_lambung}</span>
        </div>
        <div className="row" style={{ gap: 7 }}>
          <DestChip dest={t.jetty_destination} />
          <StatusPill status={t.status} />
        </div>
      </div>
      <div className="tr-meta">
        <span className="tr-sub">
          {t.status === 'pending'
            ? <>Tara <b>{kg(t.tare_site_kg)}</b> kg</>
            : t.status === 'in_transit'
              ? <>Netto site <b>{kg(t.netto_site_kg)}</b> kg</>
              : <>Netto <b>{kg(t.netto_jetty_kg)}</b> kg · dev {kg(t.deviasi_kg)}</>}
        </span>
        {tappable
          ? <span className="tr-cta">{cta} <I.chevR width="13" height="13" /></span>
          : <span className="tr-time">{toWITA(t.cp1_timestamp)}</span>}
      </div>
    </div>
  );
}

// ── list card with header ──
// getTap(t) -> handler|null ; cta = call-to-action label for tappable rows
function TripListCard({ title, sub, trips, getTap, cta, onRefresh, right }) {
  return (
    <div className="card flush">
      <div className="list-head">
        <div>
          <div className="lh-title">{title}</div>
          <div className="lh-sub">{sub}</div>
        </div>
        <div className="row" style={{ gap: 6 }}>
          {right}
          {onRefresh && (
            <button className="ah-icon-btn" style={{ width: 34, height: 34, background: 'transparent', color: 'var(--text-3)' }} onClick={onRefresh} aria-label="Segarkan">
              <I.refresh width="18" height="18" />
            </button>
          )}
        </div>
      </div>
      {trips.length === 0
        ? <div className="empty-state">Belum ada trip hari ini</div>
        : trips.map((t) => {
            const tap = getTap ? getTap(t) : null;
            return <TripRow key={t.trip_id} t={t} onTap={tap} cta={cta} />;
          })}
    </div>
  );
}

// ── segmented control ──
function Segmented({ options, value, onChange }) {
  return (
    <div className={`segmented cols-${options.length}`}>
      {options.map((o) => (
        <button key={o.value} type="button" className="seg-btn"
          aria-pressed={value === o.value} onClick={() => onChange(o.value)}>
          <span>{o.label}</span>
          {o.sub && <span className="seg-sub">{o.sub}</span>}
        </button>
      ))}
    </div>
  );
}

// ── field ──
function Field({ label, hint, children }) {
  return (
    <div className="field">
      <label className="field-label">{label}{hint && <span className="hint">{hint}</span>}</label>
      {children}
    </div>
  );
}

Object.assign(window, {
  StatusBar, Device, AppHeader, SyncChip, StatusPill, DestChip, Weight,
  TripRow, TripListCard, Segmented, Field,
});
